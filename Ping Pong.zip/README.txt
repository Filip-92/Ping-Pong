Witaj w grze Ping Pong. Jest to gra przeznaczona dla dwóch graczy.
Gracz 1 porusza lewą paletką za pomocą klawiszy A (góra) i Z (dół).
Gracz 2 porusza prawą paletką za pomocą strzałki w dół i w górę.

Celem rozgrywki jest zdobycie 10 punktów przed przeciwnikiem.
Po każdym odbiciu, prędkość piłki rośnie, aż do wygranej któregoś z graczy.
Aby rozpocząć grę, wciśnij przycisk 'Nowa Gra'.
Po każdym punkcie, możesz kontynuować grę za pomocą przycisku 'Kolejna Runda' lub
rozpocząć grę od nowa za pomocą przycisku 'Nowa Gra'.

------------------------------------------------------------------------------------------------

Welcome to Ping Pong. It is a game designed for two players.
Player 1 moves the left pallet using A (Up) and Z (Down) keys.
Player 2 moves the right pallet using Up Arrow and Down Arrow keys.

The aim of the game is achieving 10 points before the other player does.
After each strike, ball's speed is increasing until one of the players wins a round.
To start the game, press 'Nowa Gra' button.
After each point, you may continue the game using 'Kolejna Runda' button or start a new game
using 'Nowa Gra' button.